
**Title**:: Simple Marketing for Smart People
**Cover**:: ![[Book Cover - Simple Marketing for Smart People.png | 300]]
**Author**:: [[Billy Broas]] [[Tiago Forte]]
**Source**:: [amazon.co.jp/dp/B0CW1MQZXP](www.amazon.co.jp/dp/B0CW1MQZXP)


# Links
- [[IIB - Simple Marketing for Smart People]]
- [[BoaP - Simple Marketing for Smart People]]
