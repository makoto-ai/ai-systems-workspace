こちらは、おすすめ順 ショートカットキーの一覧となります。

最初は覚えなくてもいいかもですが、覚えると、圧倒的に楽になります。

ぜひたくさん練習してみてください！

### ⭐️⭐️⭐️⭐️⭐️

- 新しくノート (**N**ote) を作りたい
	- command + N

- Markdown書けないから、教えてほしい
	- /

- コマンドを忘れたので、(**P**allete)を確認して、実行したい
	- command + P

- テンプレート (**T**emplate) を使いたい
	- command + T

### ⭐️⭐️⭐️⭐️

- タイトル名で検索したい (**O**mnisearch)
	- command + O

- 単語名で、検索したい
	- option + F

- つけたリンクを、Excali**B**rainで、可視化したい
	- command + B

### ⭐️⭐️⭐️

- 設定を開きたい
	- command + ,

- 二画面に分割したい
	- control + A

- 前の画面に、戻りたい
	- command + [
	  
- 先の画面に、進みたい
	- command + ]

- Obsidianを再起動したい
	- command + shift + R

- 左右のサイドバーを、開きたい/閉じたい
	- 左
		- command + S
	- 右
		- command + R